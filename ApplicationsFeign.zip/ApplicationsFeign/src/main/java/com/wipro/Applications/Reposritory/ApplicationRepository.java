package com.wipro.Applications.Reposritory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.Applications.model.Application;

public interface ApplicationRepository extends JpaRepository<Application, Long> {

}
