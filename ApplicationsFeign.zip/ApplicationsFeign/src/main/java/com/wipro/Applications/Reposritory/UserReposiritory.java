package com.wipro.Applications.Reposritory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.Applications.model.User;

public interface UserReposiritory extends JpaRepository<User, Long>{

}
