package com.wipro.Applications.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "applications1")
public class Application {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long applicationId;

    /* Uncomment when you're ready to use these relationships
    @ManyToOne
    @JoinColumn(name = "job_id")
    private JobPosting job;

    @ManyToOne
    @JoinColumn(name = "job_seeker_id")
    private User jobSeeker; 
    */

    @NotBlank(message = "Resume cannot be blank")
    private String resume;

    @NotBlank(message = "Cover letter cannot be blank")
    private String coverLetter;

    @NotNull(message = "Application status cannot be null")
    private String applicationStatus; // Applied, Interview Scheduled, Rejected, Accepted

    @Column(name = "applied_at")
    @NotNull(message = "Applied at cannot be null")
    private LocalDateTime appliedAt;

    // Getters and Setters

    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }

    /* Uncomment when you're ready to use these relationships
    public JobPosting getJob() {
        return job;
    }

    public void setJob(JobPosting job) {
        this.job = job;
    }

    public User getJobSeeker() {
        return jobSeeker;
    }

    public void setJobSeeker(User jobSeeker) {
        this.jobSeeker = jobSeeker;
    } 
    */

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }

    public String getCoverLetter() {
        return coverLetter;
    }

    public void setCoverLetter(String coverLetter) {
        this.coverLetter = coverLetter;
    }

    public String getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(String applicationStatus) {
        this.applicationStatus = applicationStatus;
    }

    public LocalDateTime getAppliedAt() {
        return appliedAt;
    }

    public void setAppliedAt(LocalDateTime appliedAt) {
        this.appliedAt = appliedAt;
    }
}

