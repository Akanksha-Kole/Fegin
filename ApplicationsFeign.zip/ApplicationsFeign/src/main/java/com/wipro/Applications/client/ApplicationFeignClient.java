package com.wipro.Applications.client;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.netflix.ribbon.proxy.annotation.Http.Header;

import feign.Headers;
@Headers("Content-Type: application/json")
//@FeignClient(name = "emp-ws", url = "${feign.url}")

@FeignClient(name = "JobConnectApp", url = "${http://localhost:8282/api/users}")
public interface ApplicationFeignClient {	
	@GetMapping("/api/users/allusers") // it means call /products mapping from service whose name id "product-ws
	String getAllUsers();
}
// EMPLOYEE_SERVICE=http://33.25.56.120:7000

