package com.wipro.Applications;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
